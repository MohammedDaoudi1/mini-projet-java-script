function addCategory(event) {
    event.preventDefault();
    const categoryInput = document.getElementById('nom_categorie').value.trim();

    if (!categoryInput) {
        alert("Veuillez entrer une catégorie.");
        return;
    }

    let categories = JSON.parse(localStorage.getItem("categories")) || [];
    if (categories.includes(categoryInput)) {
        alert("Cette catégorie existe déjà.");
        return;
    }

    categories.push(categoryInput);
    localStorage.setItem("categories", JSON.stringify(categories));

    updateCategoryTable();
    alert("Catégorie ajoutée avec succès !");
    document.getElementById('ajoutCategorieForm').reset(); // Réinitialiser le formulaire
}

// Supprimer une catégorie de la liste
function deleteCategory(button) {
    const row = button.parentElement.parentElement;
    const categoryName = row.querySelector('td').textContent.trim();

    // Récupérer les catégories depuis localStorage
    let categories = JSON.parse(localStorage.getItem("categories")) || [];

    // Supprimer la catégorie du tableau
    categories = categories.filter(category => category !== categoryName);

    // Sauvegarder la nouvelle liste dans localStorage
    localStorage.setItem("categories", JSON.stringify(categories));

    // Supprimer la ligne du tableau affiché
    row.remove();
}


function updateCategoryTable() {
    const categoryTableBody = document.getElementById('categoryTableBody');
    categoryTableBody.innerHTML = ''; // Réinitialiser la table

    const categories = JSON.parse(localStorage.getItem("categories")) || [];
    
    categories.forEach(category => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${category}</td>
            <td><button onclick="deleteCategory(this)" class="btn btn-danger btn-sm">Supprimer</button></td>
        `;
        categoryTableBody.appendChild(row);
    });
}

// Charger les catégories au démarrage
document.addEventListener('DOMContentLoaded', function () {
    updateCategoryTable();  // Mettre à jour la table des catégories
});

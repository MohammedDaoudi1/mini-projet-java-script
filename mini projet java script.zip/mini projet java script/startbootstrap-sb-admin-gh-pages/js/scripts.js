document.addEventListener('DOMContentLoaded', function () {
    // Fonction d'enregistrement d'un utilisateur
    document.getElementById('registerForm').addEventListener('submit', function (event) {
        event.preventDefault();

        const firstName = document.getElementById('inputFirstName').value;
        const lastName = document.getElementById('inputLastName').value;
        const email = document.getElementById('inputEmail').value;
        const password = document.getElementById('inputPassword').value;
        const passwordConfirm = document.getElementById('inputPasswordConfirm').value;

        // Rôle par défaut défini sur "user"
        let role = 'user'; // Vous pouvez le modifier dynamiquement si nécessaire

        // Vérification des champs
        if (!firstName || !lastName || !email || !password || !passwordConfirm) {
            alert('Tous les champs doivent être remplis !');
            return;
        }

        if (password !== passwordConfirm) {
            alert('Les mots de passe ne correspondent pas !');
            return;
        }

        // Créer l'objet utilisateur
        const user = {
            first_name: firstName,
            last_name: lastName,
            email: email,
            password: password,
            role: role
        };

        // Récupérer les utilisateurs existants du localStorage
        let users = JSON.parse(localStorage.getItem('users')) || [];

        // Si on édite un utilisateur existant, on met à jour ses informations
        const existingUserIndex = users.findIndex(u => u.email === email);
        if (existingUserIndex > -1) {
            users[existingUserIndex] = user; // Mise à jour de l'utilisateur
        } else {
            // Sinon, on ajoute un nouvel utilisateur
            users.push(user);
        }

        // Sauvegarder les utilisateurs dans le localStorage
        localStorage.setItem('users', JSON.stringify(users));

        // Rediriger vers la page de connexion
        window.location.href = 'login.html';
    });

    // Fonction pour afficher les utilisateurs enregistrés dans gestion_utilisateurs.html
    const users = JSON.parse(localStorage.getItem('users')) || [];
    const usersTableBody = document.getElementById('usersTableBody');

    // Vider le tableau avant de le remplir
    usersTableBody.innerHTML = '';

    // Afficher chaque utilisateur
    users.forEach((user, index) => {
        const row = document.createElement('tr');

        // Ajout des classes pour les styles et accessibilité
        row.className = "align-middle text-center";

        // Remplir la ligne du tableau avec les données de l'utilisateur
        row.innerHTML = `
            <td>${user.first_name}</td>
            <td>${user.last_name}</td>
            <td>${user.email}</td>
            <td>${capitalizeRole(user.role)}</td>
            <td class="table-actions">
                <button 
                    class="btn btn-danger btn-sm rounded-pill shadow-sm" 
                    onclick="deleteUser(${index})">
                    <i class="bi bi-trash-fill"></i> Supprimer
                </button>
                <button 
                    class="btn btn-primary btn-sm rounded-pill shadow-sm" 
                    onclick="editUser(${index})">
                    <i class="bi bi-pencil-fill"></i> Modifier
                </button>
            </td>
        `;

        // Ajouter la ligne au corps du tableau
        usersTableBody.appendChild(row);
    });

    // Fonction pour mettre en majuscule la première lettre du rôle
    function capitalizeRole(role) {
        return role.charAt(0).toUpperCase() + role.slice(1).toLowerCase();
    }

    // Fonction pour supprimer un utilisateur
    window.deleteUser = function (index) {
        if (confirm('Êtes-vous sûr de vouloir supprimer cet utilisateur ?')) {
            let users = JSON.parse(localStorage.getItem('users')) || [];
            users.splice(index, 1);  // Supprimer l'utilisateur à l'index donné
            localStorage.setItem('users', JSON.stringify(users));  // Sauvegarder la nouvelle liste
            location.reload();  // Recharger la page pour afficher la liste mise à jour
        }
    };

    // Fonction pour éditer un utilisateur
    window.editUser = function (index) {
        let users = JSON.parse(localStorage.getItem('users')) || [];
        const user = users[index];

        if (user) {
            // Remplir les champs du formulaire avec les données de l'utilisateur
            document.getElementById('inputFirstName').value = user.first_name;
            document.getElementById('inputLastName').value = user.last_name;
            document.getElementById('inputEmail').value = user.email;
            document.getElementById('inputRole').value = user.role; // Permet de modifier le rôle
            document.getElementById('inputPassword').value = user.password;
            document.getElementById('inputPasswordConfirm').value = user.password;

            // Modifier le comportement du formulaire pour mettre à jour l'utilisateur
            const originalSubmitHandler = document.getElementById('registerForm').onsubmit;
            document.getElementById('registerForm').onsubmit = function (event) {
                event.preventDefault();

                user.first_name = document.getElementById('inputFirstName').value;
                user.last_name = document.getElementById('inputLastName').value;
                user.email = document.getElementById('inputEmail').value;
                user.password = document.getElementById('inputPassword').value;
                user.role = document.getElementById('inputRole').value;  // Modifier le rôle

                // Mettre à jour le localStorage avec les modifications
                users[index] = user;
                localStorage.setItem('users', JSON.stringify(users));

                // Rediriger après l'édition
                window.location.href = 'gestion_utilisateurs.html';
            };
        }
    };

    // Fonction pour la soumission du formulaire de connexion
    document.getElementById('loginForm').addEventListener('submit', function (event) {
        event.preventDefault();

        const email = document.getElementById('inputEmail').value;
        const password = document.getElementById('inputPassword').value;

        // Vérification des champs
        if (!email || !password) {
            alert('Veuillez remplir tous les champs.');
            return;
        }

        // Récupérer les utilisateurs enregistrés
        const users = JSON.parse(localStorage.getItem('users')) || [];

        // Vérifier si l'utilisateur existe et que le mot de passe est correct
        const user = users.find(u => u.email === email && u.password === password);

        if (user) {
            // Connexion réussie, enregistrer l'état de l'utilisateur et rediriger vers la page appropriée
            localStorage.setItem('userLoggedIn', 'true');
            localStorage.setItem('currentUser', JSON.stringify(user));  // Sauvegarder l'utilisateur actuel

            // Vérification du rôle de l'utilisateur
            if (user.role === 'administrateur') {
                window.location.href = 'index.html';  // Redirection vers la page admin
            } else {
                window.location.href = 'shop/index.html';  // Redirection vers la page du shop pour un utilisateur classique
            }
        } else {
            // Connexion échouée
            alert('Email ou mot de passe invalide.');
        }
    });
});
document.addEventListener('DOMContentLoaded', function () {
    // Récupérer les utilisateurs enregistrés dans localStorage
    const users = JSON.parse(localStorage.getItem('users')) || [];

    // Compter le nombre d'utilisateurs et d'administrateurs
    let userCount = 0;
    let adminCount = 0;

    users.forEach(user => {
        if (user.role === 'user') {
            userCount++;
        } else if (user.role === 'administrateur') {
            adminCount++;
        }
    });

    // Créer un graphique circulaire avec Chart.js
    const ctx = document.getElementById('userChart').getContext('2d');
    new Chart(ctx, {
        type: 'pie',
        data: {
            labels: ['Utilisateurs', 'Administrateurs'],
            datasets: [{
                data: [userCount, adminCount],
                backgroundColor: ['#FF5733', '#28A745'], // Rouge pour les utilisateurs et vert pour les administrateurs
                borderColor: ['#FF5733', '#28A745'],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
                tooltip: {
                    callbacks: {
                        label: function(tooltipItem) {
                            return tooltipItem.label + ': ' + tooltipItem.raw;
                        }
                    }
                }
            }
        }
    });
});

// Fonction pour mettre à jour le graphique des t-shirts
function updateTshirtChart() {
    const tshirts = JSON.parse(localStorage.getItem("tshirts")) || [];
    
    // Comptage du nombre de t-shirts par catégorie
    const categoryCount = {};
    tshirts.forEach(tshirt => {
        if (!categoryCount[tshirt.category]) {
            categoryCount[tshirt.category] = 0;
        }
        categoryCount[tshirt.category]++;
    });

    // Données pour le graphique
    const categories = Object.keys(categoryCount);
    const counts = Object.values(categoryCount);

    // Création du graphique avec Chart.js
    const ctx = document.getElementById('tshirtChart').getContext('2d');
    const tshirtChart = new Chart(ctx, {
        type: 'bar', // Type du graphique (barres)
        data: {
            labels: categories, // Les catégories de t-shirts
            datasets: [{
                label: 'Nombre de t-shirts par catégorie',
                data: counts, // Nombre de t-shirts par catégorie
                backgroundColor: 'rgba(75, 192, 192, 0.2)', // Couleur des barres
                borderColor: 'rgba(75, 192, 192, 1)', // Couleur de bordure des barres
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true // Commencer l'échelle à zéro
                }
            }
        }
    });
}

// Appeler la fonction pour mettre à jour le graphique après chaque ajout de t-shirt
document.addEventListener('DOMContentLoaded', function () {
    updateTshirtChart();  // Mettre à jour le graphique des t-shirts
});
document.addEventListener('DOMContentLoaded', function () {
    // Fonction pour afficher les utilisateurs dans le tableau
    const displayUsers = (users) => {
        const usersTableBody = document.getElementById('usersTableBody');
        usersTableBody.innerHTML = ''; // Vider le tableau avant d'ajouter les utilisateurs

        users.forEach((user, index) => {
            const row = document.createElement('tr');
            row.className = "align-middle text-center";

            row.innerHTML = `
                <td>${user.first_name}</td>
                <td>${user.last_name}</td>
                <td>${user.email}</td>
                <td>${capitalizeRole(user.role)}</td>
                <td class="table-actions">
                    <button class="btn btn-danger btn-sm rounded-pill shadow-sm" onclick="deleteUser(${index})">
                        <i class="bi bi-trash-fill"></i> Supprimer
                    </button>
                    <button class="btn btn-primary btn-sm rounded-pill shadow-sm" onclick="editUser(${index})">
                        <i class="bi bi-pencil-fill"></i> Modifier
                    </button>
                </td>
            `;

            usersTableBody.appendChild(row);
        });
    };

    // Fonction pour mettre en majuscule la première lettre du rôle
    function capitalizeRole(role) {
        return role.charAt(0).toUpperCase() + role.slice(1).toLowerCase();
    }

    // Fonction pour rechercher les utilisateurs
    document.getElementById('searchForm').addEventListener('submit', function (event) {
        event.preventDefault();

        const searchQuery = document.getElementById('searchInput').value.toLowerCase();
        const users = JSON.parse(localStorage.getItem('users')) || [];

        // Filtrer les utilisateurs en fonction du prénom, nom ou email
        const filteredUsers = users.filter(user =>
            user.first_name.toLowerCase().includes(searchQuery) ||
            user.last_name.toLowerCase().includes(searchQuery) ||
            user.email.toLowerCase().includes(searchQuery)
        );

        // Afficher les utilisateurs filtrés
        displayUsers(filteredUsers);
    });

    // Afficher tous les utilisateurs lorsque la page est chargée
    const users = JSON.parse(localStorage.getItem('users')) || [];
    displayUsers(users);
});
document.addEventListener('DOMContentLoaded', function () {
    const roleFilter = document.getElementById('roleFilter');
    const searchInput = document.getElementById('searchInput');
    const usersTableBody = document.getElementById('usersTableBody');
    
    // Fonction pour afficher les utilisateurs dans le tableau
    const displayUsers = (users) => {
        usersTableBody.innerHTML = ''; // Vider le tableau avant d'ajouter les utilisateurs

        // Trier les utilisateurs par nom (ordre alphabétique)
        users.sort((a, b) => a.first_name.localeCompare(b.first_name));

        users.forEach((user, index) => {
            const row = document.createElement('tr');
            row.className = "align-middle text-center";

            row.innerHTML = `
                <td>${user.first_name}</td>
                <td>${user.last_name}</td>
                <td>${user.email}</td>
                <td>${capitalizeRole(user.role)}</td>
                <td class="table-actions">
                    <button class="btn btn-danger btn-sm rounded-pill shadow-sm" onclick="deleteUser(${index})">
                        <i class="bi bi-trash-fill"></i> Supprimer
                    </button>
                    <button class="btn btn-primary btn-sm rounded-pill shadow-sm" onclick="editUser(${index})">
                        <i class="bi bi-pencil-fill"></i> Modifier
                    </button>
                </td>
            `;
            usersTableBody.appendChild(row);
        });
    };

    // Fonction pour mettre en majuscule la première lettre du rôle
    function capitalizeRole(role) {
        return role.charAt(0).toUpperCase() + role.slice(1).toLowerCase();
    }

    // Fonction pour rechercher et filtrer les utilisateurs
    const filterUsers = () => {
        const searchQuery = searchInput.value.toLowerCase();
        const roleQuery = roleFilter.value.toLowerCase();
        const users = JSON.parse(localStorage.getItem('users')) || [];

        // Filtrer les utilisateurs en fonction du prénom, nom, email et rôle
        const filteredUsers = users.filter(user => {
            const matchesRole = roleQuery ? user.role.toLowerCase() === roleQuery : true;
            const matchesSearch = user.first_name.toLowerCase().includes(searchQuery) ||
                                  user.last_name.toLowerCase().includes(searchQuery) ||
                                  user.email.toLowerCase().includes(searchQuery);
            return matchesRole && matchesSearch;
        });

        displayUsers(filteredUsers);
    };

    // Ajouter un événement sur le formulaire de recherche
    searchInput.addEventListener('input', filterUsers);

    // Ajouter un événement sur le filtre de rôle
    roleFilter.addEventListener('change', filterUsers);

    // Afficher tous les utilisateurs au chargement de la page
    const users = JSON.parse(localStorage.getItem('users')) || [];
    displayUsers(users);
});

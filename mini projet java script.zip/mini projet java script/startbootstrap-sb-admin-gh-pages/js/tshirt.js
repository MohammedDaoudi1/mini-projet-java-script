// Ajouter ou mettre à jour un t-shirt
function addOrUpdateTshirt(event) {
    event.preventDefault();

    const tshirtName = document.getElementById('nom_tshirt').value;
    const tshirtDescription = document.getElementById('description').value;
    const tshirtPrice = document.getElementById('prix').value;
    const tshirtImage = document.getElementById('image_tshirt').files[0];
    const tshirtCategory = document.getElementById('categorie').value; // Récupération de la catégorie
    const tshirtId = document.getElementById('tshirtId').value; // ID caché pour modification

    if (!tshirtName || !tshirtDescription || !tshirtPrice || !tshirtImage || !tshirtCategory) {
        alert("Veuillez remplir tous les champs, sélectionner une catégorie, et ajouter une photo.");
        return;
    }

    // Fonction pour compresser l'image
    function compressImage(imageFile, maxWidth = 800, maxHeight = 800) {
        return new Promise((resolve, reject) => {
            const img = new Image();
            const reader = new FileReader();

            reader.onload = function (e) {
                img.src = e.target.result;
            };

            reader.onerror = function (error) {
                reject(error);
            };

            reader.readAsDataURL(imageFile);

            img.onload = function () {
                const canvas = document.createElement('canvas');
                const ctx = canvas.getContext('2d');

                // Calculer les dimensions pour garder le ratio d'aspect
                let width = img.width;
                let height = img.height;

                if (width > maxWidth) {
                    height = Math.round(height * (maxWidth / width));
                    width = maxWidth;
                }

                if (height > maxHeight) {
                    width = Math.round(width * (maxHeight / height));
                    height = maxHeight;
                }

                canvas.width = width;
                canvas.height = height;
                ctx.drawImage(img, 0, 0, width, height);

                const compressedDataUrl = canvas.toDataURL('image/jpeg', 0.7);  // Compresser l'image avec 70% de qualité
                resolve(compressedDataUrl);
            };
        });
    }

    compressImage(tshirtImage).then(compressedImage => {
        const tshirtData = {
            name: tshirtName,
            description: tshirtDescription,
            price: tshirtPrice,
            category: tshirtCategory,
            image: compressedImage // Image compressée en base64
        };

        let tshirts = JSON.parse(localStorage.getItem("tshirts")) || [];

        // Si un ID est présent, c'est une modification
        if (tshirtId) {
            const index = tshirts.findIndex(tshirt => tshirt.id === parseInt(tshirtId));
            if (index !== -1) {
                tshirtData.id = parseInt(tshirtId);
                tshirts[index] = tshirtData; // Mise à jour du t-shirt
            }
        } else {
            // Si pas d'ID, ajout d'un nouveau t-shirt
            tshirtData.id = Date.now(); // Utilisation de l'heure actuelle pour l'ID unique
            tshirts.push(tshirtData);
        }

        localStorage.setItem("tshirts", JSON.stringify(tshirts));
        updateTshirtTable();  // Mettre à jour la table immédiatement après l'ajout

        alert(tshirtId ? "T-shirt modifié avec succès !" : "T-shirt ajouté avec succès !");
        document.getElementById('ajoutTshirtForm').reset(); // Réinitialiser le formulaire
        document.getElementById('tshirtId').value = ''; // Réinitialiser l'ID pour un nouvel ajout
    }).catch(error => {
        alert("Erreur lors de la compression de l'image : " + error.message);
    });
}

// Mettre à jour le tableau des t-shirts
function updateTshirtTable() {
    const tableBody = document.getElementById('tableBody');
    tableBody.innerHTML = ''; // Réinitialiser le tableau pour éviter les doublons

    const tshirts = JSON.parse(localStorage.getItem("tshirts")) || [];

    tshirts.forEach((tshirt, index) => {
        const row = document.createElement('tr');
        row.dataset.id = tshirt.id;
        row.style.opacity = 0; // Masquer initialement
        row.style.transform = "translateY(20px)"; // Déplacer vers le bas initialement

        row.innerHTML = `
            <td>${tshirt.name}</td>
            <td>${tshirt.description}</td>
            <td>${tshirt.price}</td>
            <td>${tshirt.category}</td>
            <td><img src="${tshirt.image}" alt="${tshirt.name}" width="50"></td>
            <td>
                <button onclick="editTshirt(${tshirt.id})" class="btn btn-warning btn-sm">Modifier</button>
                <button onclick="deleteTshirt(${tshirt.id})" class="btn btn-danger btn-sm">Supprimer</button>
            </td>
        `;

        tableBody.appendChild(row);

        // Appliquer une animation au chargement
        setTimeout(() => {
            row.style.opacity = 1;
            row.style.transform = "translateY(0)";
        }, index * 100); // Un décalage pour chaque ligne
    });
}

// Supprimer un t-shirt
function deleteTshirt(tshirtId) {
    let tshirts = JSON.parse(localStorage.getItem("tshirts")) || [];
    tshirts = tshirts.filter(tshirt => tshirt.id !== tshirtId); // Filtrer le t-shirt à supprimer

    localStorage.setItem("tshirts", JSON.stringify(tshirts));
    updateTshirtTable(); // Mettre à jour le tableau après suppression
}

// Editer un t-shirt
function editTshirt(tshirtId) {
    const tshirts = JSON.parse(localStorage.getItem("tshirts")) || [];
    const tshirtToEdit = tshirts.find(tshirt => tshirt.id === tshirtId);

    if (tshirtToEdit) {
        document.getElementById('nom_tshirt').value = tshirtToEdit.name;
        document.getElementById('description').value = tshirtToEdit.description;
        document.getElementById('prix').value = tshirtToEdit.price;
        document.getElementById('categorie').value = tshirtToEdit.category;
        document.getElementById('tshirtId').value = tshirtToEdit.id;
        document.getElementById('submitButton').textContent = "Mettre à jour le T-shirt"; // Modifier le texte du bouton
    }
}

// Charger les catégories dans le formulaire d'ajout de T-shirt
function loadCategories() {
    const categories = JSON.parse(localStorage.getItem("categories")) || [];
    const categorySelect = document.getElementById('categorie');
    
    // Vider le select avant de le remplir
    categorySelect.innerHTML = '';

    // Ajouter une option vide par défaut
    const defaultOption = document.createElement('option');
    defaultOption.value = '';
    defaultOption.textContent = 'Sélectionner une catégorie';
    categorySelect.appendChild(defaultOption);

    // Ajouter les catégories dans le select
    categories.forEach(category => {
        const option = document.createElement('option');
        option.value = category;
        option.textContent = category;
        categorySelect.appendChild(option);
    });
}

// Appeler la fonction pour charger les catégories au démarrage
document.addEventListener('DOMContentLoaded', function () {
    loadCategories(); // Charger les catégories dans le formulaire
    updateTshirtTable();  // Mettre à jour la table des t-shirts
});
window.searchUsers = function (event) {
    event.preventDefault(); // Empêcher la soumission du formulaire

    const searchQuery = document.getElementById('searchInput').value.toLowerCase();
    const filteredUsers = users.filter(user => 
        user.first_name.toLowerCase().includes(searchQuery) || 
        user.last_name.toLowerCase().includes(searchQuery)
    );
    displayUsers(filteredUsers); // Afficher les utilisateurs filtrés
};

// Fonction pour afficher les utilisateurs
function displayUsers(users) {
    const usersList = document.getElementById('usersList');  // L'élément où les utilisateurs seront affichés

    // Vider la liste avant d'ajouter les résultats
    usersList.innerHTML = '';

    if (users.length === 0) {
        usersList.innerHTML = '<p>Aucun utilisateur trouvé.</p>';
        return;
    }

    // Afficher chaque utilisateur dans la liste
    users.forEach(user => {
        const userItem = document.createElement('li');
        userItem.textContent = `${user.first_name} ${user.last_name}`;
        usersList.appendChild(userItem);
    });
}
document.addEventListener('DOMContentLoaded', function () {
    // Fonction pour afficher les t-shirts dans le tableau
    function displayTshirts(tshirts) {
        const tableBody = document.getElementById('tableBody');
        tableBody.innerHTML = ''; // Vider le tableau avant d'ajouter les t-shirts

        if (tshirts.length === 0) {
            tableBody.innerHTML = '<tr><td colspan="6" class="text-center">Aucun t-shirt trouvé.</td></tr>';
            return;
        }

        tshirts.forEach((tshirt, index) => {
            const row = document.createElement('tr');
            row.dataset.id = tshirt.id;
            row.style.opacity = 0; // Masquer initialement
            row.style.transform = "translateY(20px)"; // Déplacer vers le bas initialement

            row.innerHTML = `
                <td>${tshirt.name}</td>
                <td>${tshirt.description}</td>
                <td>${tshirt.price}</td>
                <td>${tshirt.category}</td>
                <td><img src="${tshirt.image}" alt="${tshirt.name}" width="50"></td>
                <td>
                    <button onclick="editTshirt(${tshirt.id})" class="btn btn-warning btn-sm">Modifier</button>
                    <button onclick="deleteTshirt(${tshirt.id})" class="btn btn-danger btn-sm">Supprimer</button>
                </td>
            `;

            tableBody.appendChild(row);

            // Appliquer une animation au chargement
            setTimeout(() => {
                row.style.opacity = 1;
                row.style.transform = "translateY(0)";
            }, index * 100); // Un décalage pour chaque ligne
        });
    }

    // Fonction de recherche des t-shirts
    document.getElementById('searchForm').addEventListener('submit', function (event) {
        event.preventDefault(); // Empêcher le rechargement de la page

        const searchQuery = document.getElementById('searchInput').value.toLowerCase();
        const tshirts = JSON.parse(localStorage.getItem('tshirts')) || [];

        // Filtrer les t-shirts en fonction du nom
        const filteredTshirts = tshirts.filter(tshirt =>
            tshirt.name.toLowerCase().includes(searchQuery)
        );

        // Afficher les t-shirts filtrés
        displayTshirts(filteredTshirts);
    });

    // Charger les t-shirts au démarrage
    const tshirts = JSON.parse(localStorage.getItem('tshirts')) || [];
    displayTshirts(tshirts);
});
document.addEventListener('DOMContentLoaded', function () {
    // Fonction pour afficher les t-shirts dans le tableau
    function displayTshirts(tshirts) {
        const tableBody = document.getElementById('tableBody');
        tableBody.innerHTML = ''; // Vider le tableau avant d'ajouter les t-shirts

        if (tshirts.length === 0) {
            tableBody.innerHTML = '<tr><td colspan="6" class="text-center">Aucun t-shirt trouvé.</td></tr>';
            return;
        }

        tshirts.forEach((tshirt, index) => {
            const row = document.createElement('tr');
            row.dataset.id = tshirt.id;
            row.style.opacity = 0; // Masquer initialement
            row.style.transform = "translateY(20px)"; // Déplacer vers le bas initialement

            row.innerHTML = `
                <td>${tshirt.name}</td>
                <td>${tshirt.description}</td>
                <td>${tshirt.price}</td>
                <td>${tshirt.category}</td>
                <td><img src="${tshirt.image}" alt="${tshirt.name}" width="50"></td>
                <td>
                    <button onclick="editTshirt(${tshirt.id})" class="btn btn-warning btn-sm">Modifier</button>
                    <button onclick="deleteTshirt(${tshirt.id})" class="btn btn-danger btn-sm">Supprimer</button>
                </td>
            `;

            tableBody.appendChild(row);

            // Appliquer une animation au chargement
            setTimeout(() => {
                row.style.opacity = 1;
                row.style.transform = "translateY(0)";
            }, index * 100); // Un décalage pour chaque ligne
        });
    }

    // Charger les catégories dans le formulaire de filtre
    function loadCategoriesForFilter() {
        const categories = JSON.parse(localStorage.getItem("categories")) || [];
        const categorySelect = document.getElementById('categoryFilter');
        
        // Vider le select avant de le remplir
        categorySelect.innerHTML = '';

        // Ajouter une option vide par défaut
        const defaultOption = document.createElement('option');
        defaultOption.value = '';
        defaultOption.textContent = 'Sélectionner une catégorie';
        categorySelect.appendChild(defaultOption);

        // Ajouter les catégories dans le select
        categories.forEach(category => {
            const option = document.createElement('option');
            option.value = category;
            option.textContent = category;
            categorySelect.appendChild(option);
        });
    }

    // Charger les t-shirts au démarrage
    const tshirts = JSON.parse(localStorage.getItem('tshirts')) || [];
    displayTshirts(tshirts);

    // Ajouter l'événement de filtrage par catégorie
    document.getElementById('categoryFilterForm').addEventListener('submit', function (event) {
        event.preventDefault(); // Empêcher le rechargement de la page

        const selectedCategory = document.getElementById('categoryFilter').value;
        const allTshirts = JSON.parse(localStorage.getItem('tshirts')) || [];

        // Si une catégorie est sélectionnée, filtrer les t-shirts
        const filteredTshirts = selectedCategory ? 
            allTshirts.filter(tshirt => tshirt.category === selectedCategory) : 
            allTshirts;

        // Afficher les t-shirts filtrés
        displayTshirts(filteredTshirts);
    });

    // Charger les catégories dans le filtre au démarrage
    loadCategoriesForFilter();
});

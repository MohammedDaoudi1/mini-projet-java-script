// Charger les produits dans le panier depuis le localStorage
const cart = JSON.parse(localStorage.getItem('cart')) || [];
const tshirts = JSON.parse(localStorage.getItem('tshirts')) || [];
const cartContent = document.getElementById('cartContent');

// Vérifier si le panier est vide
if (cart.length === 0) {
    cartContent.innerHTML = `<p class="text-center">Votre panier est vide.</p>`;
} else {
    cart.forEach((productId, index) => {
        const product = tshirts.find(tshirt => tshirt.id === productId); // Récupérer les détails du produit

        if (product) {
            const productCard = document.createElement('div');
            productCard.classList.add('row', 'mb-3');
            productCard.innerHTML = `
                <div class="col-4">
                    <img src="${product.image}" alt="${product.name}" class="img-fluid" />
                </div>
                <div class="col-8">
                    <h5>${product.name}</h5>
                    <p>Prix : $${product.price}</p>
                    <button class="btn btn-danger" onclick="removeFromCart(${index})">Supprimer</button>
                </div>
            `;
            cartContent.appendChild(productCard);
        }
    });
}

// Fonction pour supprimer un produit du panier
function removeFromCart(index) {
    cart.splice(index, 1); // Supprimer le produit par son index dans le panier
    localStorage.setItem('cart', JSON.stringify(cart)); // Sauvegarder le panier mis à jour
    window.location.reload(); // Recharger la page pour mettre à jour l'affichage
}

// Gérer le passage à la caisse
document.getElementById('checkoutBtn').addEventListener('click', () => {
    const isLoggedIn = localStorage.getItem('userLoggedIn') === 'true';
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    const userEmail = currentUser ? currentUser.email : null;

    if (isLoggedIn) {
        // Afficher le formulaire de paiement
        const checkoutContent = document.getElementById('checkoutContent');
        const cartItems = cart
            .map(productId => tshirts.find(tshirt => tshirt.id === productId))
            .filter(product => product); // Filtrer les produits valides uniquement

        // Calculer le prix total
        let totalPrice = cartItems.reduce((total, item) => {
            const itemPrice = parseFloat(item.price); // Convertir le prix en nombre
            return total + (isNaN(itemPrice) ? 0 : itemPrice); // Ajouter 0 si le prix n'est pas valide
        }, 0);

        // Vérifier si totalPrice est un nombre valide
        if (isNaN(totalPrice) || totalPrice === 0) {
            alert("Erreur dans le calcul du total. Vérifiez les produits dans le panier.");
            return;
        }

        checkoutContent.innerHTML = `
            <div class="card p-4 mb-4">
                <h5 class="text-center mb-4">Détails de la Commande</h5>
                <div id="orderDetails">
                    <h6>Articles : </h6>
                    ${cartItems.map(item => `<p>${item.name} - $${item.price}</p>`).join('')}
                </div>
                <h6>Total : $${totalPrice.toFixed(2)}</h6>
                <h6>Numéro de Carte Bancaire : </h6>
                <input type="text" id="cardNumber" class="form-control mb-3" placeholder="Entrez votre numéro de carte" />
                <button id="purchaseBtn" class="btn btn-primary w-100">Acheter</button>
            </div>
        `;

        // Assurer qu'un seul événement est attaché au bouton "Acheter"
        document.getElementById('purchaseBtn').onclick = () => {
            const cardNumber = document.getElementById('cardNumber').value.trim();

            if (cardNumber.length < 16 || isNaN(cardNumber)) {
                alert('Le numéro de carte est invalide.');
                return;
            }

            // Créer la commande en simplifiant les données stockées (pas d'images, pas de description)
            const newOrder = {
                userEmail: userEmail,
                items: cartItems.map(item => ({
                    id: item.id,
                    name: item.name,
                    price: item.price
                })), // Stocker uniquement les informations essentielles
                total: totalPrice,
                date: new Date().toISOString(),
                status: 'En attente',
            };

            // Ajouter la commande aux commandes existantes
            const orders = JSON.parse(localStorage.getItem('orders')) || [];
            orders.push(newOrder);

            // Sauvegarder les commandes mises à jour dans le localStorage
            localStorage.setItem('orders', JSON.stringify(orders));

            // Vider le panier après la commande
            localStorage.setItem('cart', JSON.stringify([]));

            // Rediriger vers la page de gestion des commandes
            alert('Votre commande a été passée avec succès !');
            window.location.href = '../index.html';
        };
    } else {
        alert('Vous devez vous connecter pour passer une commande.');
        window.location.href = 'login.html'; // Redirige vers la page de connexion
    }
});

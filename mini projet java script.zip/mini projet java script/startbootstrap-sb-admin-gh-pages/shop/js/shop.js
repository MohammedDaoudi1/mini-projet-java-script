// Fonction pour vérifier si l'utilisateur est connecté
function checkLoginStatus() {
    return localStorage.getItem('userLoggedIn') === 'true';
}

// Charger l'ID utilisateur
function getUserId() {
    return localStorage.getItem('userId');
}

const userId = getUserId();

// Vérifie si l'utilisateur est connecté
const isLoggedIn = checkLoginStatus();
const cartCountBadge = document.getElementById('cartCount');
const cartBtn = document.getElementById('cartBtn');
const signUpBtn = document.getElementById('signUpBtn');
const loginBtn = document.getElementById('loginBtn');
const logoutBtn = document.getElementById('logoutBtn');

// Si l'utilisateur est connecté, on masque les boutons "Sign Up" et "Log In", on affiche le panier et le bouton "Déconnexion"
if (isLoggedIn) {
    signUpBtn.style.display = 'none';
    loginBtn.style.display = 'none';
    cartBtn.style.display = 'block';
    logoutBtn.style.display = 'block';
} else {
    signUpBtn.style.display = 'block';
    loginBtn.style.display = 'block';
    cartBtn.style.display = 'none';
    logoutBtn.style.display = 'none';
}

// Fonction de déconnexion
logoutBtn.addEventListener('click', () => {
    localStorage.removeItem('userLoggedIn'); // Retirer l'état de connexion
    window.location.href = 'index.html'; // Rediriger vers la page d'accueil après la déconnexion
});

// Charger les T-shirts depuis le localStorage
const tshirts = JSON.parse(localStorage.getItem('tshirts')) || [];
const productContainer = document.getElementById('shop-products');

// Charger le contenu du panier
const cart = JSON.parse(localStorage.getItem('cart')) || [];
cartCountBadge.textContent = cart.length;

// Générer les cartes de produits
tshirts.forEach((tshirt, index) => {
    const productCard = document.createElement('div');
    productCard.classList.add('col', 'mb-5');

    productCard.innerHTML = `
        <div class="card h-100">
            <img class="card-img-top" src="${tshirt.image}" alt="${tshirt.name}" />
            <div class="card-body p-4">
                <div class="text-center">
                    <h5 class="fw-bolder">${tshirt.name}</h5>
                    <span>$${tshirt.price}</span><br />
                    <span class="text-muted">${tshirt.category}</span>
                </div>
            </div>
            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                <div class="text-center">
                    <button class="btn btn-outline-dark mt-auto" data-bs-toggle="modal" data-bs-target="#productDetailModal" data-product-index="${index}">Voir les détails</button>
                    <button class="btn btn-outline-primary mt-2" id="addToCartBtn-${index}" ${!isLoggedIn ? 'disabled' : ''}>Ajouter au panier</button>
                </div>
            </div>
        </div>
    `;

    productContainer.appendChild(productCard);

    // Ajouter au panier
    const addToCartBtn = document.getElementById(`addToCartBtn-${index}`);
    addToCartBtn.addEventListener('click', () => {
        if (isLoggedIn) {
            if (!cart.includes(tshirt.id)) {
                cart.push(tshirt.id);
                localStorage.setItem('cart', JSON.stringify(cart));
                cartCountBadge.textContent = cart.length;
                alert(`${tshirt.name} ajouté au panier !`);
            } else {
                alert('Cet article est déjà dans le panier.');
            }
        } else {
            alert('Vous devez vous connecter pour ajouter des articles au panier.');
        }
    });
});

// Lorsque le bouton "Voir les détails" est cliqué, afficher les détails du produit dans la modal
document.querySelectorAll('[data-bs-toggle="modal"]').forEach(button => {
    button.addEventListener("click", (event) => {
        const productIndex = event.target.getAttribute("data-product-index");
        const product = tshirts[productIndex];
        const modalBody = document.getElementById("productDetailsBody");

        modalBody.innerHTML = `
            <div class="text-center">
                <img src="${product.image}" alt="${product.name}" class="img-fluid mb-3" />
                <h5 class="fw-bolder">${product.name}</h5>
                <p>${product.description}</p>
                <p class="text-muted">Catégorie : ${product.category}</p>
                <button class="btn btn-success mb-3" id="buyNowBtn">Ajouter au panier</button>
                <div class="d-flex justify-content-center">
                    <button class="btn btn-outline-primary me-2" id="commentBtn">Ton avis</button>
                </div>
                <div id="commentsSection"></div>
            </div>
        `;

        // Ajouter au panier depuis la modal
        document.getElementById("buyNowBtn").addEventListener("click", () => {
            if (isLoggedIn) {
                if (!cart.includes(product.id)) {
                    cart.push(product.id);
                    localStorage.setItem('cart', JSON.stringify(cart));
                    cartCountBadge.textContent = cart.length;
                    alert(`${product.name} ajouté au panier !`);
                } else {
                    alert('Cet article est déjà dans le panier.');
                }
            } else {
                alert('Vous devez vous connecter pour ajouter des articles au panier.');
            }
        });

        // Gérer l'ajout de commentaire
        document.getElementById("commentBtn").addEventListener("click", () => {
            const commentSection = document.getElementById("commentsSection");
            const commentText = document.createElement("textarea");
            commentText.placeholder = "Entrez votre commentaire ici...";
            commentText.classList.add("form-control", "mb-3");

            const submitCommentBtn = document.createElement("button");
            submitCommentBtn.textContent = "Soumettre le commentaire";
            submitCommentBtn.classList.add("btn", "btn-primary");

            commentSection.innerHTML = ""; // Effacer le contenu précédent
            commentSection.appendChild(commentText);
            commentSection.appendChild(submitCommentBtn);

            // Soumettre le commentaire
            submitCommentBtn.addEventListener("click", () => {
                const userComment = commentText.value.trim();
                if (userComment) {
                    const newComment = document.createElement("div");
                    newComment.classList.add("alert", "alert-info", "mt-2");
                    newComment.textContent = userComment;
                    commentSection.appendChild(newComment);

                    // Effacer la zone de texte après soumission
                    commentText.value = "";
                }
            });
        });
    });
});

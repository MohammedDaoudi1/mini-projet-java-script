function handleFormSubmit(event) {
    event.preventDefault(); // Empêche le rechargement de la page

    // Récupération des données du formulaire
        const name = document.getElementById('name').value;
        const email = document.getElementById('email').value;
        const subject = document.getElementById('subject').value;
        const message = document.getElementById('message').value;

        // Création d'un tableau pour stocker les messages
        let messages = JSON.parse(localStorage.getItem('messages')) || [];

        // Ajouter le message au tableau
        messages.push({ name, email, subject, message });

        // Sauvegarder dans le localStorage
        localStorage.setItem('messages', JSON.stringify(messages));

        // Rediriger vers gestion_messages.html
        window.location.href = '../gestion_messages.html';
    }

